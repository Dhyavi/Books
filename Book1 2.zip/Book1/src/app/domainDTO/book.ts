
export interface Book {
    name: string;
    author: string;
    available: number;
    price: string;
  }
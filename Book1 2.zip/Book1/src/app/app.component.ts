import { Component ,OnInit} from '@angular/core';
import { MatListModule } from '@angular/material';
import {MatTableDataSource} from '@angular/material';
import {Book} from './domainDTO/book';
import{BookService} from './services/bookService';
import {MatFormFieldModule} from '@angular/material/form-field';

@Component({

  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  title = 'Book1';

books:Book[];
  displayedColumns = [ 'name','author', 'available', 'price'];
   dataSource = new MatTableDataSource<Book>();
  constructor(private bookService:BookService) {



bookService.getAllBooks().subscribe((data:any)=>{this.books=data;
console.log(this.books,"djh");
this.dataSource.data=this.books;
}) 


}
    ngOnInit() {
       /*  this.dataSource = new LessonsDataSource(this.coursesService);
        this.dataSource.loadLessons(1); */
        this.dataSource.data=this.books;

    }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}

import { Injectable } from '@angular/core';
import{Book}from '../domainDTO/book';
import { Observable } from 'rxjs';
import { HttpClientModule }    from '@angular/common/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root',
  })
  export class BookService {
    url='../assets/book.json';

    constructor(private http: HttpClient) { }
  
getAllBooks():Observable<Book[]>{
   return this.http.get<Book[]>(this.url);


}



  }